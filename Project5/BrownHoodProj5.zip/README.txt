Unfortunatly dynamic does not work correctly. I belive it has something to due with the non-neighbor nodes' lengths not being reset.


